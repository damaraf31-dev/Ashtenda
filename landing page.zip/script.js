// --- data ---
const products = [
  ['Tenda Sarnafil','Tenda utama untuk acara outdoor berskala besar.','tent'],
  ['Tenda Plafon','Tampilan interior rapi dengan plafon kain premium.','tent'],
  ['Tenda Transparan','Kesan elegan dan terang untuk acara malam.','tent'],
  ['Tenda Roder','Struktur kokoh untuk kapasitas besar.','tent'],
  ['Kursi Futura','Kursi modern untuk kenyamanan tamu.','chair'],
  ['Meja Bundar','Meja bundar untuk resepsi dan gala dinner.','table'],
  ['Meja IBM','Meja lipat serbaguna untuk berbagai layout.','table'],
  ['Panggung','Panggung modular sesuai kebutuhan acara.','stage'],
  ['Backdrop','Latar panggung custom sesuai tema.','stage'],
  ['Partisi','Pembatas ruang untuk booth dan area acara.','panel'],
  ['Karpet Event','Karpet premium untuk area acara.','panel'],
  ['AC Standing','Pendingin ruangan portable untuk tenda.','ac'],
  ['Sound System','Tata suara jernih untuk indoor & outdoor.','sound'],
  ['Lighting','Pencahayaan ambient hingga stage lighting.','light'],
];

const icons = {
  tent:'<path d="M30 8 54 40 6 40 Z"/><path d="M30 8v32"/><path d="M10 40v6h40v-6"/>',
  chair:'<path d="M16 44V26a6 6 0 0 1 6-6h16a6 6 0 0 1 6 6v18"/><path d="M16 44h28M18 44v6M42 44v6"/>',
  table:'<ellipse cx="30" cy="20" rx="18" ry="7"/><path d="M14 20v8M46 20v8M30 27v18"/>',
  stage:'<path d="M8 40h44v-6H8z"/><path d="M14 34l6-14h20l6 14"/>',
  panel:'<rect x="12" y="10" width="14" height="32" rx="1"/><rect x="34" y="10" width="14" height="32" rx="1"/>',
  ac:'<rect x="8" y="14" width="44" height="14" rx="2"/><path d="M14 32v6M24 32v8M34 32v6M44 32v8"/>',
  sound:'<rect x="12" y="8" width="24" height="36" rx="2"/><circle cx="24" cy="18" r="5"/><circle cx="24" cy="34" r="7"/>',
  light:'<path d="M22 8h16l-4 14h6l-16 20 4-16h-6z"/>',
};

const iconSvg = key => `<svg viewBox="0 0 60 50" fill="none" stroke="#10233d" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" opacity="0.7">${icons[key]}</svg>`;

document.querySelector('#tenda').innerHTML = products.map(([name,desc,icon])=>`
  <div class="card group bg-white rounded-2xl overflow-hidden border border-black/5">
    <div class="card-img aspect-[4/3] bg-mist flex items-center justify-center p-8">${iconSvg(icon)}</div>
    <div class="p-6">
      <h3 class="font-serif text-xl text-navy mb-1">${name}</h3>
      <p class="text-sm text-char/60 mb-4">${desc}</p>
      <a href="#kontak" class="text-sm text-navy border-b border-navy/30 hover:border-navy transition-colors">Lihat Detail</a>
    </div>
  </div>`).join('');

const events = [
  ['Wedding','Tenda dan dekorasi elegan untuk hari bahagia Anda.'],
  ['Corporate Event','Setup profesional untuk acara perusahaan.'],
  ['Exhibition','Booth dan partisi untuk pameran produk.'],
  ['Bazaar','Tenda dan perlengkapan untuk area bazaar.'],
  ['Gathering','Suasana nyaman untuk acara kebersamaan.'],
  ['Seminar','Panggung dan sound system untuk presentasi.'],
  ['Launching','Setup mengesankan untuk peluncuran produk.'],
  ['Festival','Perlengkapan lengkap untuk acara berskala besar.'],
];
document.querySelector('#event-grid').innerHTML = events.map(([t,d])=>`
  <div class="rounded-2xl bg-mist p-6 aspect-[4/5] flex flex-col justify-end">
    <h3 class="font-serif text-xl text-navy mb-2">${t}</h3>
    <p class="text-sm text-char/60">${d}</p>
  </div>`).join('');

const why = [
  ['Beragam Perlengkapan','Tenda dan perlengkapan event tersedia dalam berbagai pilihan.'],
  ['Tim Berpengalaman','Didukung tim yang memahami kebutuhan setup acara.'],
  ['Flexible Setup','Penyesuaian perlengkapan berdasarkan konsep dan kebutuhan venue.'],
  ['Area Jakarta & Sekitarnya','Melayani kebutuhan event di Jakarta dan area sekitarnya.'],
  ['Konsultasi Langsung','Diskusikan kebutuhan acara sebelum menentukan perlengkapan.'],
];
document.querySelector('#why-grid').innerHTML = why.map(([t,d])=>`
  <div>
    <div class="w-9 h-9 rounded-full bg-brass/15 mb-4"></div>
    <h3 class="text-navy font-medium mb-2">${t}</h3>
    <p class="text-sm text-char/60 leading-relaxed">${d}</p>
  </div>`).join('');

const portfolio = ['Wedding Setup','Corporate Event','Bazaar','Exhibition','Outdoor Event','Tent Setup'];
const spans = ['col-span-2 row-span-2','','','col-span-2','','col-span-2'];
document.querySelector('#portfolio-grid').innerHTML = portfolio.map((t,i)=>`
  <div class="${spans[i]} rounded-2xl bg-gradient-to-br from-mist to-mist2 aspect-square flex items-end p-4">
    <span class="text-navy/70 text-sm">${t}</span>
  </div>`).join('');

// reveal on scroll
const io = new IntersectionObserver(entries=>{
  entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
},{threshold:0.12});
document.querySelectorAll('section').forEach(s=>{ s.classList.add('reveal'); io.observe(s); });
